list1 = [1,2,3]
tupple1 = ("a", "b", "c", 1)
print(list1)
print(type(list1))
print(tupple1)
print(type(tupple1))