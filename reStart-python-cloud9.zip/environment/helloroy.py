python -version
